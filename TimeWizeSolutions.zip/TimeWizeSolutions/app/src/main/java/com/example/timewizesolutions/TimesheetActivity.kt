package com.example.timewizesolutions

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.util.UUID

class TimesheetActivity : AppCompatActivity() {
    companion object {
        const val REQUEST_IMAGE_PICK_CODE = 100
    }

    private lateinit var timesheetNameEditText: EditText
    private lateinit var descriptionEditText: EditText
    private lateinit var projectSpinner: Spinner
    private lateinit var startDateEditText: EditText
    private lateinit var endDateEditText: EditText
    private lateinit var timeGoalEditText: EditText
    private lateinit var uploadImageButton: Button
    private lateinit var submitButton: Button
    private lateinit var backButton: Button
    private lateinit var mDatabase: DatabaseReference
    private lateinit var mStorage: StorageReference
    private var imageUri: Uri? = null
    private lateinit var projectList: ArrayList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timesheet)

        timesheetNameEditText = findViewById(R.id.timesheetNameEditText)
        descriptionEditText = findViewById(R.id.descriptionEditText)
        projectSpinner = findViewById(R.id.projectSpinner)
        startDateEditText = findViewById(R.id.startDateEditText)
        endDateEditText = findViewById(R.id.endDateEditText)
        timeGoalEditText = findViewById(R.id.timeGoalEditText)
        uploadImageButton = findViewById(R.id.uploadImageButton)
        submitButton = findViewById(R.id.submitButton)
        backButton = findViewById(R.id.backButton)

        mDatabase = FirebaseDatabase.getInstance().getReference("timesheets")
        mStorage = FirebaseStorage.getInstance().reference


        projectList = ArrayList()
        fetchProjectNames()


        uploadImageButton.setOnClickListener {

            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                pickImageFromGallery()
            } else {

                requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_IMAGE_PICK_CODE)
            }
        }


        submitButton.setOnClickListener {
            submitTimesheetData()
        }


        backButton.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun fetchProjectNames() {
        val projectRef = FirebaseDatabase.getInstance().getReference("projects")
        projectRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (projectSnapshot in snapshot.children) {
                        val projectName = projectSnapshot.child("name").getValue(String::class.java)!!
                        projectList.add(projectName)
                    }
                    val adapter = ArrayAdapter(this@TimesheetActivity, android.R.layout.simple_spinner_item, projectList)
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    projectSpinner.adapter = adapter
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@TimesheetActivity, "Failed to fetch projects: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            val selectedImageUri: Uri? = data?.data

        } else {
            Toast.makeText(this, "Failed to pick image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        pickImageLauncher.launch(intent)
    }

    private fun submitTimesheetData() {
        val timesheetName = timesheetNameEditText.text.toString().trim()
        val description = descriptionEditText.text.toString().trim()
        val selectedProject = projectSpinner.selectedItem.toString()
        val startDate = startDateEditText.text.toString().trim()
        val endDate = endDateEditText.text.toString().trim()
        val timeGoal = timeGoalEditText.text.toString().trim()


        if (TextUtils.isEmpty(timesheetName) || TextUtils.isEmpty(description) || selectedProject == "Select Project" || TextUtils.isEmpty(startDate) || TextUtils.isEmpty(endDate) || TextUtils.isEmpty(timeGoal)) {
            Toast.makeText(this, "Please fill in all required fields!", Toast.LENGTH_SHORT).show()
            return
        }


        val timesheetData = HashMap<String, Any>()
        timesheetData["name"] = timesheetName
        timesheetData["description"] = description
        timesheetData["project"] = selectedProject
        timesheetData["startDate"] = startDate
        timesheetData["endDate"] = endDate
        timesheetData["timeGoal"] = timeGoal.toInt()


        if (imageUri != null) {
            val storageRef = mStorage.child("timesheet_images/${UUID.randomUUID()}")
            storageRef.putFile(imageUri!!)
                .addOnSuccessListener { snapshot ->
                    val downloadUrl = snapshot.metadata?.reference?.downloadUrl.toString()
                    timesheetData["imageUrl"] = downloadUrl

                    pushDataToDatabase(timesheetData)
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(this, "Failed to upload image: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
        } else {

            pushDataToDatabase(timesheetData)
        }
    }

    private fun pushDataToDatabase(timesheetData: HashMap<String, Any>) {
        val newTimesheetId = mDatabase.push().key
        if (newTimesheetId != null) {
            timesheetData["id"] = newTimesheetId.toInt()
        }
        if (newTimesheetId != null) {
            mDatabase.child(newTimesheetId).setValue(timesheetData)
                .addOnSuccessListener {
                    Toast.makeText(this, "Timesheet submitted successfully!", Toast.LENGTH_SHORT).show()

                    timesheetNameEditText.text.clear()
                    descriptionEditText.text.clear()
                    projectSpinner.setSelection(0)
                    startDateEditText.text.clear()
                    endDateEditText.text.clear()
                    timeGoalEditText.text.clear()
                    imageUri = null
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(this, "Failed to submit timesheet: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }


}