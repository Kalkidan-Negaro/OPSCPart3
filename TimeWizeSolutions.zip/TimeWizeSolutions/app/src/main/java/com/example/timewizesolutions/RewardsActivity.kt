package com.example.timewizesolutions

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class RewardsActivity : AppCompatActivity() {

    private lateinit var rewardsTextView: TextView
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rewards)

        rewardsTextView = findViewById(R.id.rewardsTextView)
        database = FirebaseDatabase.getInstance().reference

        checkRewards()
    }

    private fun checkRewards() {
        database.child("timesheets").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val timesheetCount = snapshot.childrenCount

                val rewards = mutableListOf<String>()

                if (timesheetCount >= 5) {
                    rewards.add("Reward for having 5 timesheets")
                }
                if (timesheetCount >= 10) {
                    rewards.add("Reward for having 10 timesheets")
                }


                if (rewards.isEmpty()) {
                    rewardsTextView.text = "No rewards yet. Keep working!"
                } else {
                    rewardsTextView.text = rewards.joinToString("\n")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                rewardsTextView.text = "Failed to load rewards: ${error.message}"
            }
        })
    }


}
