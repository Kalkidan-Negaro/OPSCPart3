package com.example.timewizesolutions

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PomodoroActivity : AppCompatActivity() {

    private lateinit var timerTextView: TextView
    private lateinit var startStopButton: Button
    private lateinit var statusTextView: TextView
    private lateinit var backButton: Button

    private var isRunning = false
    private lateinit var countDownTimer: CountDownTimer
    private var timeLeftInMillis = 1500000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pomodoro_timer)

        timerTextView = findViewById(R.id.timerTextView)
        startStopButton = findViewById(R.id.startStopButton)
        statusTextView = findViewById(R.id.statusTextView)
        backButton = findViewById(R.id.backButton)

        startStopButton.setOnClickListener {
            if (isRunning) {
                pauseTimer()
            } else {
                startTimer()
            }
        }

        backButton.setOnClickListener {
            val intent = Intent(this, WelcomeActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun startTimer() {
        countDownTimer = object : CountDownTimer(timeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeftInMillis = millisUntilFinished
                updateTimerText()
            }

            override fun onFinish() {
                isRunning = false
                startStopButton.text = "Start"
                statusTextView.text = "Pomodoro Finished!"
                Toast.makeText(this@PomodoroActivity, "Time's up!", Toast.LENGTH_SHORT).show()
            }
        }.start()

        isRunning = true
        startStopButton.text = "Pause"
        statusTextView.text = "Pomodoro Running..."
    }

    private fun pauseTimer() {
        countDownTimer.cancel()
        isRunning = false
        startStopButton.text = "Start"
        statusTextView.text = "Pomodoro Paused"
    }

    private fun updateTimerText() {
        val minutes = (timeLeftInMillis / 1000) / 60
        val seconds = (timeLeftInMillis / 1000) % 60
        val timeFormatted = String.format("%02d:%02d", minutes, seconds)
        timerTextView.text = timeFormatted
    }
}
