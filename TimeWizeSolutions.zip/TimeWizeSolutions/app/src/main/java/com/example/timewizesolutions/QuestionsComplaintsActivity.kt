package com.example.timewizesolutions

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class QuestionsComplaintsActivity : AppCompatActivity() {

    private lateinit var questionComplaintEditText: EditText
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.acitivity_questions_and_complaints)

        questionComplaintEditText = findViewById(R.id.questionComplaintEditText)
        submitButton = findViewById(R.id.submitButton)


        submitButton.setOnClickListener {
            val questionComplaint = questionComplaintEditText.text.toString().trim()


            if (questionComplaint.isEmpty()) {
                Toast.makeText(this, "Please enter your question or complaint", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            Toast.makeText(this, "Question/complaint submitted!", Toast.LENGTH_SHORT).show()

            questionComplaintEditText.text.clear()
        }


        val backButton = findViewById<Button>(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }
    }
}
