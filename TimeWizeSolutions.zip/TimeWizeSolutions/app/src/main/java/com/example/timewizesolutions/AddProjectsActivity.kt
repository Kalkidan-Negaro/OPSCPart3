package com.example.timewizesolutions

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class AddProjectsActivity : AppCompatActivity() {

    private lateinit var projectNameEditText: EditText
    private lateinit var companyNameEditText: EditText
    private lateinit var addProjectButton: Button
    private lateinit var backButton: Button
    private lateinit var mDatabase: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.acitivity_add_projects)

        projectNameEditText = findViewById(R.id.projectNameEditText)
        companyNameEditText = findViewById(R.id.companyNameEditText)
        addProjectButton = findViewById(R.id.addProjectButton)
        backButton = findViewById(R.id.backButton)

        mDatabase = FirebaseDatabase.getInstance().getReference("projects")

        // Add Project button click listener
        addProjectButton.setOnClickListener {
            val projectName = projectNameEditText.text.toString().trim()
            val companyName = companyNameEditText.text.toString().trim()

            if (projectName.isEmpty()) {
                Toast.makeText(this, "Please enter a project name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (companyName.isEmpty()) {
                Toast.makeText(this, "Please enter a company name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Create a Project object with project and company names
            val project = Project(projectName, companyName)

            // Save project to Firebase database
            val key = mDatabase.push().key
            mDatabase.child(key!!).setValue(project)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Project added successfully!", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, HomeActivity::class.java) // Go back to HomeActivity
                        startActivity(intent)
                        finish() // Close AddProjectsActivity
                    } else {
                        Toast.makeText(this, "Failed to add project: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
        }

        // Back button click listener
        backButton.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            startActivity(intent)
            finish() // Close AddProjectsActivity
        }
    }

    data class Project(val name: String, val company: String)
}
