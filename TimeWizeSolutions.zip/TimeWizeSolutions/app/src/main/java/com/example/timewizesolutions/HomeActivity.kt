package com.example.timewizesolutions

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    private lateinit var timesheetButton: Button
    private lateinit var addProjectsButton: Button
    private lateinit var pomodoroTimerButton: Button
    private lateinit var rewardsButton: Button
    private lateinit var profileButton: Button
    private lateinit var questionsComplaintsButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        timesheetButton = findViewById(R.id.timesheetButton)
        addProjectsButton = findViewById(R.id.addProjectsButton)
        pomodoroTimerButton = findViewById(R.id.pomodoroTimerButton)
        rewardsButton = findViewById(R.id.rewardsButton)
        profileButton = findViewById(R.id.profileButton)
        questionsComplaintsButton = findViewById(R.id.questionsComplaintsButton)


        timesheetButton.setOnClickListener {
            val intent = Intent(this, TimesheetActivity::class.java)
            startActivity(intent)
        }


        addProjectsButton.setOnClickListener {
            val intent = Intent(this, AddProjectsActivity::class.java)
            startActivity(intent)
        }


        pomodoroTimerButton.setOnClickListener {
            val intent = Intent(this, PomodoroActivity::class.java)
            startActivity(intent)
        }

        rewardsButton.setOnClickListener {
            val intent = Intent(this, RewardsActivity::class.java)
            startActivity(intent)
        }


        profileButton.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        questionsComplaintsButton.setOnClickListener {
            val intent = Intent(this, QuestionsComplaintsActivity::class.java)
            startActivity(intent)
        }
    }
}
